import logo from './logo.svg';
import './App.css';
import Student from './Student';
import Employee from './Employee';


function App() {
  return (
    <>
      <h1>Data Entry Form</h1>
  
      <Employee/>
  
    </>
    );
}

export default App;
