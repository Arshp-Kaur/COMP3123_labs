import React from "react";
class Employee extends React.Component{
    constructor(props){
        super(props)

        this.state ={
            FirstName : "",
            LastName: "",
            Address: "",
            ContactNo: "",
            Sex: "",
        }
    }

    onSubmitData = (event) => {
        event.preventDefault()
        console.log(this.state)
    }

    onValueChange = event => {

        this.setState({
            [event.target.name]:  event.target.value
        })

    }

    render(){
        return(
        <div>
           
            <form onSubmit={e => this.onSubmitData(e)}>
                <input onChange={e => this.onValueChange(e)} type="text" name="FirstName" placeholder="FirstName" />
                <br></br>
                <input onChange={e => this.onValueChange(e)} type="text" name="LastName" placeholder="LastName" />
                <br></br>
                <input onChange={e => this.onValueChange(e)} type="text" name="Address" placeholder="Address" />
                <br></br>
                <input onChange={e => this.onValueChange(e)} type="text" name="ContactNo" placeholder="ContactNo" />
                <br></br>
                <input onChange={e => this.onValueChange(e)} type="text" name="Sex" placeholder="Sex" />
                <br></br>
                <select name="Province" id="Province" placeholder="Choose?">
                 <option value="Ontario">Ontario</option>
                 <option value="Alberta">Alberta</option>
                 <option value="Manitoba">Manitoba</option>
                 <option value="New Brunswick">New Brunswick</option>
                 <option value="Newfoundland and Labrador">Newfoundland and Labrador</option>
                 <option value="Nova Scotia">Nova Scotia</option>
                 <option value="Saskatchewan">Saskatchewan</option>

                </select>
              
                <input type="checkbox" name="checkbox" value="check" id="agree" /> Agree Terms & Conditions?
                <input onChange={e => this.onValueChange(e)} type="submit" name="submit " placeholder="Submt" />
                <input type="Reset" value="Reset"/>
                
         
            </form>
            <h2>Data Output</h2>
               <h5>Email:{this.state.FirstName}</h5>
               <h5>Name:{this.state.LastName}</h5>
               <h5>Address:{this.state.Address}</h5>
               <h5>ContactNo:{this.state.ContactNo}</h5>
               <h5>Sex:{this.state.Sex}</h5>
               <h5>Province:{this.state.Province}</h5>
                </div>

        )
    }
}

export default Employee